import { Component } from '@angular/core';

@Component({
  selector: 'scoss-events',
  templateUrl: './events.component.html',
  styleUrl: './events.component.scss'
})
export class EventsComponent {

}
