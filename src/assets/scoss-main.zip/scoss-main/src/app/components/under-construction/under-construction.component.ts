import { Component } from '@angular/core';
import { ServicesOffered } from '../../common/models/services-offered';

@Component({
  selector: 'scoss-under-construction',
  templateUrl: './under-construction.component.html',
  styleUrl: './under-construction.component.scss'
})
export class UnderConstructionComponent {

}
