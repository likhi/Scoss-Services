import { Component } from '@angular/core';

@Component({
  selector: 'scoss-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss'
})
export class ContactComponent {

}
