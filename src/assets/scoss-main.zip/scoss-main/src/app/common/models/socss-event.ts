export interface ScossEvent {
    name: string;
    img: string;
    alt: string;
    isCompleted: boolean;
}