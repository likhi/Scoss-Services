export interface ServicesOffered {
        title: string;
        iconURL: string;
        description: string;
        features: string;
        buttonName: string;
        routerLink: string;
}
