import { ScossEvent } from "./socss-event";

export { ScossEvent }