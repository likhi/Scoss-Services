import { EventComponent } from "./event/event.component";
import { HeaderComponent } from "./header/header.component";

export { HeaderComponent, EventComponent }